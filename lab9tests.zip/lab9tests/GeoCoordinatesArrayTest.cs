using lab9;
namespace lab9tests;

[TestClass]
public sealed class GeoCoordinatesArrayTest
{
    [TestMethod]
    public void CorrectlySetArrayLength()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);
        int testValue = 11;
        testArray.ManuallyChangeArray(11);
        
        Assert.AreEqual(testArray.Length(), testValue);
    }

    [TestMethod]
    public void CantSetWrongArrayLength()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);

        void TestFuction()
        {
            testArray.ManuallyChangeArray(-1);
        }
        Assert.ThrowsException<IndexOutOfRangeException>(TestFuction);
    }

    [TestMethod]
    public void CantSelectNonInitElement()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);
        testArray.ManuallyChangeArray(11);
        GeoCoordinates gc1 = new GeoCoordinates
            
        {
            Latitude = 80,
            Longtitude = 80
        };
        
        void TestFunc()
        {
            testArray[-1] = gc1;
        }

        Assert.ThrowsException<IndexOutOfRangeException>(TestFunc);
    }

    [TestMethod]
    public void CantReturnNonExistArray()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);
        testArray.ManuallyChangeArray(11);
        
        void MoreThanLength()
        {
            testArray.ReturnElement(12);
        }
        void LessThanLength()
        {
            testArray.ReturnElement(-1);
        }
        Assert.ThrowsException<IndexOutOfRangeException>(MoreThanLength);
        Assert.ThrowsException<IndexOutOfRangeException>(LessThanLength);
    }

    [TestMethod]
    public void CorrectlySetPointInArray()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);
        testArray.ManuallyChangeArray(11);
        GeoCoordinates gc1 = new GeoCoordinates
        {
            Latitude = 80,
            Longtitude = 80
        };
        
        testArray[0] = gc1;
        
        Assert.AreEqual(testArray.ReturnElement(0).Longtitude, gc1.Longtitude);
        Assert.AreEqual(testArray.ReturnElement(0).Latitude, gc1.Latitude);
    }

    [TestMethod]
    public void CorrectlyCalculatesClosestToZero()
    {
        GeoCoordinatesArray testArray = new GeoCoordinatesArray([]);
        testArray.ManuallyChangeArray(2);
        GeoCoordinates gc1 = new GeoCoordinates
        {
            Latitude = 80,
            Longtitude = 80
        };
        GeoCoordinates gc2 = new GeoCoordinates
        {
            Latitude = 1,
            Longtitude = 1
        };
        string compareWith = $"Ближайшим к Острову 'Ноль' оказалась точка 1;1 на расстоянии 157,24938127194397";

        testArray[0] = gc1;
        testArray[1] = gc2;

        string TestFunc()
        {
            return testArray.CompareToIslandZero();
        }
        
        Assert.AreEqual(TestFunc(), compareWith);
    }
}
