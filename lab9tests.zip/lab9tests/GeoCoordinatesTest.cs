﻿using lab9;
namespace lab9tests;
[TestClass]
public sealed class GeoCoordinatesTest
{
    private static int _instanceCount = 0;
    public void InstanceAppend()
    {
        _instanceCount++;
    }
    /*
    [TestInitialize]
    public void bebebeb()
    {
        Console.WriteLine("beforeEach");
    }
    
    [TestCleanup]
    public void cleanup()
    {
        Console.WriteLine("afterEach");

    }
    */
    [TestMethod]
    public void InstanceCountCountsCorrectly()
    {
        // из-за особенности статического метода InstanceCount
        // привычная логика Arrange-Act-Assert будет немного нарушена
        Assert.AreEqual(_instanceCount, GeoCoordinates.InstanceCount);
    }
    [TestMethod]
    public void CantExitBounds()
    {
        // ARRANGE
        GeoCoordinates testSubject = new GeoCoordinates();
        InstanceAppend();
        //ACT
        void TestLongtitudeUpperBounds()
        {
            testSubject.Longtitude = 190;
        }

        void TestLongtitudeLowerBounds()
        {
            testSubject.Longtitude = -190;
        }

        void TestLatitudeUpperBounds()
        {
            testSubject.Latitude = 100;
        }

        void TestLatitudeLowerBounds()
        {
            testSubject.Latitude = -100;
        }
        //ASSERT
        Assert.ThrowsException<Exception>(TestLongtitudeUpperBounds);
        Assert.ThrowsException<Exception>(TestLongtitudeLowerBounds);
        Assert.ThrowsException<Exception>(TestLatitudeUpperBounds);
        Assert.ThrowsException<Exception>(TestLatitudeLowerBounds);
    }
    
    // метод Initialize зависит от конструкторов Latitude Longtitude и ручного ввода, в котором уже стоит 
    // ограничение, тестировать не стоит
    [TestMethod]
    public void PointShowsCorrectly()
    {
        Random rnd = new Random();
        double gcLat = rnd.Next(-90, 90);
        double gcLon = rnd.Next(-180, 180);
        string comparedString = $"{gcLat};{gcLon}";
        GeoCoordinates testedGc = new GeoCoordinates
        {
            Longtitude = gcLon, Latitude = gcLat
        };
        Assert.AreEqual(comparedString, testedGc.Show());
    }
    [TestMethod]
    public void IsDistanceCalculatedCorrectly()
    {
        // arrange
        var gc1 = new GeoCoordinates();
        gc1.Longtitude = 110.5;
        gc1.Latitude = -88.4;
        InstanceAppend();
        var gc2 = new GeoCoordinates();
        gc2.Longtitude = -134.2;
        gc2.Latitude = 76.9;
        InstanceAppend();
        int expectedResult = 18625;
        
        // act
        double result = GeoCoordinates.CalculateDistance(gc1, gc2);
        result = Math.Round(result);
        
        // assert
        Assert.AreEqual(expectedResult, result);
    }

    [TestMethod]
    public void CanAppend()
    {
        //arrange
        var gcTested = new GeoCoordinates();
        gcTested.Latitude = 80;
        gcTested.Longtitude = 170;
        InstanceAppend();
        var gcComparer = new GeoCoordinates();
        gcComparer.Latitude = 80;
        gcComparer.Longtitude = 170;
        InstanceAppend();
        //act
        gcTested.Append();
        
        //assert
        Assert.AreNotEqual(gcTested.Longtitude, gcComparer.Longtitude);
        Assert.AreNotEqual(gcTested.Latitude, gcComparer.Latitude);
    }
    [TestMethod]
    public void CantAppendIfCloseToMax()
    {
        //arrange
        var gcTested = new GeoCoordinates();
        gcTested.Latitude = 90;
        gcTested.Longtitude = 180;
        InstanceAppend();
        var gcComparer = new GeoCoordinates();
        gcComparer.Latitude = 90;
        gcComparer.Longtitude = 180;
        InstanceAppend();
        //act
        gcTested.Append();
        
        //assert
        Assert.AreEqual(gcTested.Longtitude, gcComparer.Longtitude);
        Assert.AreEqual(gcTested.Latitude, gcComparer.Latitude);
    }

    [TestMethod]
    public void CanReverse()
    {
        //arrange
        GeoCoordinates gcTested = new GeoCoordinates
        {
            Latitude = 90, Longtitude = 180
        };
        GeoCoordinates gcCompared = new GeoCoordinates
        {
            Latitude = -90, Longtitude = -180
        };
        InstanceAppend();
        InstanceAppend();
        //act
        gcTested.Reverse();
        
        //assert
        Assert.AreEqual(gcTested.Latitude, gcCompared.Latitude);
        Assert.AreEqual(gcTested.Longtitude, gcCompared.Longtitude);
    }

    [TestMethod]
    public void CanUnderstandIfEquator()
    {
        GeoCoordinates gcTested = new GeoCoordinates
        {
            Latitude = 0, Longtitude = 0
        };
        InstanceAppend();
        bool methodResult;
        
        methodResult = gcTested.OnEquator();
        
        Assert.AreEqual(methodResult, true);
        
        gcTested.Append();

        methodResult = gcTested.OnEquator();
        
        Assert.AreEqual(methodResult, false);
    }

    [TestMethod]
    public void CanUnderstandLongtitude()
    {
        string testConst1 = "Точка находится на восточном меридиане.";
        string testConst2 = "Точка находится на западном меридиане.";
        string testConst3 = "Точка находится на нулевом меридиане.";
        GeoCoordinates gcTested = new GeoCoordinates
        {
            Longtitude = 1, Latitude = 10
        };
        InstanceAppend();
        Assert.AreEqual(testConst1, gcTested.WhatLongtitude());
        gcTested.Reverse();
        Assert.AreEqual(testConst2, gcTested.WhatLongtitude());
        gcTested.Longtitude = 0;
        Assert.AreEqual(testConst3, gcTested.WhatLongtitude());
    }

    [TestMethod] public void CanCompareMeridianAndParallel()
    {
        GeoCoordinates gcTested1 = new GeoCoordinates
        {
            Latitude = 0, Longtitude = 0
        };
        GeoCoordinates gcTested2 = new GeoCoordinates();
        gcTested2.CopyData(gcTested1);
        Assert.AreEqual(GeoCoordinates.IsSameMeridian(gcTested1, gcTested2), true);
        Assert.AreEqual(GeoCoordinates.IsSameParallel(gcTested1, gcTested2), true);
        gcTested1.Append();
        Assert.AreEqual(GeoCoordinates.IsSameMeridian(gcTested1, gcTested2), false);
        Assert.AreEqual(GeoCoordinates.IsSameParallel(gcTested1, gcTested2), false);
    }
}